# Kijiji Phone Number Scraper

A Python-based web scraper that extracts phone numbers from Kijiji car listings in Ontario, Canada using Selenium WebDriver.

## Features

- **Automated Navigation**: Navigates through multiple pages of Kijiji car listings
- **Phone Number Extraction**: Detects and reveals hidden phone numbers from listings
- **Real-time CSV Updates**: Saves extracted data to CSV file as it processes each listing
- **Robust Error Handling**: Handles various edge cases and network issues
- **Progress Tracking**: Detailed logging of scraping progress
- **Duplicate Prevention**: Avoids processing the same listing multiple times

## Installation

1. **Clone or download the project files**

2. **Install dependencies**:
   ```bash
   python setup.py
   ```
   
   Or manually install:
   ```bash
   pip install -r requirements.txt
   ```

3. **Chrome Browser**: Make sure you have Google Chrome installed (the scraper uses Chrome WebDriver)

## Usage

### Basic Usage

Run the scraper with default settings:
```bash
python kijiji_scraper.py
```

### Configuration Options

You can modify the scraper behavior by editing the `main()` function in `kijiji_scraper.py`:

```python
scraper.scrape_listings(
    start_url=start_url,
    max_pages=5,      # Limit pages (None for all pages)
    max_listings=50   # Limit listings (None for all listings)
)
```

### Headless Mode

To run without opening a browser window, modify the scraper initialization:
```python
scraper = KijijiScraper(headless=True)
```

## Output

The scraper creates a CSV file with the following columns:
- `listing_id`: Unique identifier for the listing
- `title`: Vehicle title/description
- `price`: Listed price
- `location`: Seller location
- `phone_number`: Extracted phone number (or 'N/A' if not available)
- `listing_url`: Direct link to the listing
- `scraped_at`: Timestamp when data was extracted

### Sample Output
```csv
listing_id,title,price,location,phone_number,listing_url,scraped_at
1725698304,2021 Subaru Crosstrek Ltd.,$20000,Barry's Bay,+1-613-555-0123,https://www.kijiji.ca/v-cars-trucks/...,2025-01-22T10:30:45
```

## How It Works

1. **Page Navigation**: Starts from the Ontario cars & trucks page filtered for owner listings
2. **Listing Detection**: Identifies all vehicle listings on each page
3. **Individual Processing**: Clicks on each listing to access the detail page
4. **Phone Number Extraction**: 
   - Detects if a phone number is available
   - Clicks "Reveal" button if phone number is hidden
   - Extracts the revealed phone number
5. **Data Storage**: Immediately saves extracted data to CSV file
6. **Pagination**: Automatically moves to next page and continues

## Target Elements

The scraper looks for these specific elements on Kijiji:

- **Listing Container**: `ul[data-testid="srp-search-list"]`
- **Individual Listings**: `a[data-testid="listing-link"]`
- **Page Load Indicator**: `.sc-30b4d0e2-2.jFnPsI`
- **Phone Container**: `.sc-30b4d0e2-3.iFFiBy`
- **Reveal Button**: `button.sc-adc2db3f-0.cLDdWI.sc-608879d0-0.cbUwJX`
- **Revealed Phone**: `a[href^='tel:']`

## Logging

The scraper creates detailed logs in:
- Console output (real-time progress)
- `kijiji_scraper.log` file (persistent logging)

## Error Handling

The scraper handles various scenarios:
- Network timeouts and connection issues
- Missing page elements
- Blocked or inaccessible listings
- Rate limiting and anti-bot measures
- Duplicate listing detection

## Rate Limiting

The scraper includes built-in delays:
- 2-3 seconds between listing requests
- 3 seconds after revealing phone numbers
- Additional waits for page loading

## Limitations

- **Terms of Service**: Ensure compliance with Kijiji's Terms of Service
- **Rate Limits**: Kijiji may implement rate limiting or anti-bot measures
- **Dynamic Content**: Page structure changes may require scraper updates
- **Phone Number Availability**: Not all listings include phone numbers

## Troubleshooting

### Common Issues

1. **Chrome Driver Issues**:
   - The scraper automatically downloads the correct ChromeDriver
   - Ensure Chrome browser is installed and up-to-date

2. **Element Not Found Errors**:
   - Kijiji may have updated their page structure
   - Check the log files for specific error details

3. **Slow Performance**:
   - Increase delay times in the script
   - Run in headless mode for better performance

4. **Access Blocked**:
   - Kijiji may temporarily block automated access
   - Try running with longer delays or different user agents

### Debug Mode

For debugging, you can:
- Set `headless=False` to see browser actions
- Increase logging verbosity
- Add breakpoints in the code

## Legal and Ethical Considerations

- **Respect robots.txt**: Check Kijiji's robots.txt file
- **Rate Limiting**: Don't overwhelm their servers
- **Personal Data**: Handle phone numbers responsibly
- **Terms of Service**: Comply with Kijiji's terms
- **Commercial Use**: Check licensing requirements

## Contributing

Feel free to improve the scraper by:
- Adding support for other provinces/regions
- Improving error handling
- Adding more data extraction fields
- Optimizing performance

## Disclaimer

This tool is for educational and research purposes. Users are responsible for complying with all applicable laws and website terms of service. Use responsibly and ethically.
