#!/usr/bin/env python3
"""
Configuration file for Kijiji Scraper
"""

# Scraping Configuration
SCRAPER_CONFIG = {
    # Browser settings
    'headless': False,  # Set to True to run without opening browser window
    'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',

    # Timing settings (in seconds) - Optimized for speed
    'page_load_timeout': 4,        # Reduced from 15 to 10
    'element_wait_timeout': 8,      # Reduced from 15 to 8
    'between_listings_delay': 1,    # Reduced from 2 to 1
    'after_reveal_delay': 1,        # Reduced from 3 to 1 (handled in code now)
    'page_navigation_delay': 2,     # Reduced from 3 to 2

    # Limits (set to reasonable numbers for initial testing)
    'max_pages': 2,         # Limit to 2 pages for testing, set to None for unlimited
    'max_listings': 10,     # Limit to 10 listings for testing, set to None for unlimited

    # Retry settings
    'max_retries': 5,
    'retry_delay': 5,
}

# CSS Selectors
SELECTORS = {
    # Main page elements
    'search_results_list': 'ul[data-testid="srp-search-list"]',
    'listing_links': 'a[data-testid="listing-link"]',
    'next_page_button': 'a[aria-label*="Next"], a[title*="Next"]',

    # Listing page elements
    'page_load_indicator': '.sc-30b4d0e2-2.jFnPsI',
    'phone_reveal_button': 'button.sc-adc2db3f-0.cLDdWI.sc-608879d0-0.cbUwJX',
    'image_element': 'sc-3930aaf4-2 bAqjYF',

    # Data extraction elements
    'title': 'h1',
    'price_elements': '[data-testid*="price"], .sc-54de28bc-3, .price',
    'description_element': '[data-testid="vip-description-wrapper"]',

}

# CSV Configuration
CSV_CONFIG = {
    'filename_prefix': 'Listings',
    'include_timestamp': True,
    'headers': [
        'listing_id',
        'title',
        'price',
        'description',
        'image_url',
        'listing_url',
    ]
}

# Logging Configuration
LOGGING_CONFIG = {
    'level': 'INFO',  # DEBUG, INFO, WARNING, ERROR, CRITICAL
    'format': '%(asctime)s - %(levelname)s - %(message)s',
    'log_to_file': True,
    'log_filename': 'kijiji_scraper.log',
    'log_to_console': True
}
