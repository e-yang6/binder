#!/usr/bin/env python3
"""
Test script for Kijiji Scraper
This script runs a limited test to verify the scraper works correctly.
"""

from kijiji_scraper import KijijiScraper
from config import URLS, SCRAPER_CONFIG
import logging

# Set up logging for test
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_scraper():
    """Run a limited test of the scraper."""
    logger.info("Starting Kijiji Scraper Test")
    logger.info("=" * 50)
    
    # Test configuration - limit to just a few listings
    test_config = {
        'max_pages': 1,      # Only test first page
        'max_listings': 3    # Only process 3 listings
    }
    
    try:
        # Initialize scraper
        scraper = KijijiScraper(headless=False)  # Keep browser visible for testing
        
        logger.info("Scraper initialized successfully")
        logger.info(f"CSV file will be saved as: {scraper.csv_filename}")
        
        # Test with Ontario cars & trucks URL
        test_url = URLS['ontario_cars_trucks']
        logger.info(f"Testing with URL: {test_url}")
        
        # Run limited scrape
        scraper.scrape_listings(
            start_url=test_url,
            max_pages=test_config['max_pages'],
            max_listings=test_config['max_listings']
        )
        
        logger.info("Test completed successfully!")
        logger.info(f"Check the CSV file: {scraper.csv_filename}")
        
    except KeyboardInterrupt:
        logger.info("Test interrupted by user")
    except Exception as e:
        logger.error(f"Test failed: {str(e)}")
        raise

def main():
    """Main test function."""
    try:
        test_scraper()
    except Exception as e:
        logger.error(f"Test error: {str(e)}")
        print("\n" + "="*50)
        print("TEST FAILED")
        print("Check the error messages above for details.")
        print("Common issues:")
        print("- Chrome browser not installed")
        print("- Network connectivity problems")
        print("- Kijiji website structure changes")
        print("="*50)

if __name__ == "__main__":
    main()
