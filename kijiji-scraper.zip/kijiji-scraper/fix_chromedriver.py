#!/usr/bin/env python3
"""
Fix ChromeDriver issues by clearing cache and reinstalling
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path

def clear_webdriver_cache():
    """Clear WebDriverManager cache."""
    try:
        # Common WebDriverManager cache locations
        cache_paths = [
            Path.home() / '.wdm',
            Path.home() / 'AppData' / 'Local' / '.wdm',
            Path(os.environ.get('USERPROFILE', '')) / '.wdm'
        ]
        
        for cache_path in cache_paths:
            if cache_path.exists():
                print(f"Removing cache directory: {cache_path}")
                shutil.rmtree(cache_path, ignore_errors=True)
                print(f"✓ Removed {cache_path}")
        
        print("✓ WebDriverManager cache cleared")
        return True
        
    except Exception as e:
        print(f"Error clearing cache: {e}")
        return False

def reinstall_webdriver_manager():
    """Reinstall webdriver-manager."""
    try:
        print("Reinstalling webdriver-manager...")
        subprocess.check_call([sys.executable, "-m", "pip", "uninstall", "webdriver-manager", "-y"])
        subprocess.check_call([sys.executable, "-m", "pip", "install", "webdriver-manager"])
        print("✓ webdriver-manager reinstalled")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error reinstalling webdriver-manager: {e}")
        return False

def test_chrome_installation():
    """Test if Chrome is properly installed."""
    try:
        # Try to find Chrome executable
        chrome_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            r"C:\Users\{}\AppData\Local\Google\Chrome\Application\chrome.exe".format(os.environ.get('USERNAME', ''))
        ]
        
        chrome_found = False
        for path in chrome_paths:
            if os.path.exists(path):
                print(f"✓ Found Chrome at: {path}")
                chrome_found = True
                break
        
        if not chrome_found:
            print("❌ Chrome browser not found!")
            print("Please install Google Chrome from: https://www.google.com/chrome/")
            return False
        
        return True
        
    except Exception as e:
        print(f"Error checking Chrome: {e}")
        return False

def main():
    """Main fix function."""
    print("🔧 ChromeDriver Fix Tool")
    print("=" * 50)
    
    # Step 1: Check Chrome installation
    print("\n1. Checking Chrome installation...")
    if not test_chrome_installation():
        return
    
    # Step 2: Clear WebDriverManager cache
    print("\n2. Clearing WebDriverManager cache...")
    clear_webdriver_cache()
    
    # Step 3: Reinstall webdriver-manager
    print("\n3. Reinstalling webdriver-manager...")
    if not reinstall_webdriver_manager():
        return
    
    print("\n✅ ChromeDriver fix completed!")
    print("\nNow try running the test again:")
    print("python test_scraper.py")

if __name__ == "__main__":
    main()
