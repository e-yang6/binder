#!/usr/bin/env python3
import os
import csv
import time
import re
import logging
from datetime import datetime
from typing import List, Dict, Optional, Tuple
import pandas as pd

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import (
    TimeoutException,
    NoSuchElementException,
    ElementClickInterceptedException,
    StaleElementReferenceException,
    WebDriverException
)
from webdriver_manager.chrome import ChromeDriverManager

# Import configuration
from config import SCRAPER_CONFIG, SELECTORS, CSV_CONFIG, LOGGING_CONFIG

# Configure logging
handlers = []
if LOGGING_CONFIG['log_to_file']:
    handlers.append(logging.FileHandler(LOGGING_CONFIG['log_filename']))
if LOGGING_CONFIG['log_to_console']:
    handlers.append(logging.StreamHandler())

logging.basicConfig(
    level=getattr(logging, LOGGING_CONFIG['level']),
    format=LOGGING_CONFIG['format'],
    handlers=handlers
)
logger = logging.getLogger(__name__)

class KijijiScraper:
    def __init__(self, headless: bool = None):
        """Initialize the Kijiji scraper with Chrome WebDriver."""
        self.driver = None
        self.wait = None
        self.headless = headless if headless is not None else SCRAPER_CONFIG['headless']

        # Folder to store CSV files
        self.csv_folder = 'CSV'

        # Generate CSV filename
        if CSV_CONFIG['include_timestamp']:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            self.csv_filename = f"{CSV_CONFIG['filename_prefix']}.csv"
        else:
            self.csv_filename = f"{CSV_CONFIG['filename_prefix']}.csv"

        self.scraped_data = []
        self.processed_listings = set()  # Track processed listing IDs to avoid duplicates

        # Initialize CSV file
        self._init_csv()

    def _init_csv(self):
        """Initialize the CSV file with headers if it doesn't already exist."""
        # Create CSV folder if not exists
        os.makedirs(self.csv_folder, exist_ok=True)
        csv_path = os.path.join(self.csv_folder, self.csv_filename)

        # Only create headers if file does not exist
        if not os.path.exists(csv_path):
            with open(csv_path, 'w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(CSV_CONFIG['headers'])
            logger.info(f"Created new CSV file: {csv_path}")
        else:
            logger.info(f"Appending to existing CSV file: {csv_path}")

        # Save path for later writes
        self.csv_filename = csv_path

    def _setup_driver(self):
        """Set up Chrome WebDriver with appropriate options."""
        try:
            chrome_options = Options()

            if self.headless:
                chrome_options.add_argument("--headless")

            # Additional options for better stability
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            chrome_options.add_argument(f"--user-agent={SCRAPER_CONFIG['user_agent']}")

            # Try to get the correct ChromeDriver
            try:
                service = Service(ChromeDriverManager().install())
            except Exception as driver_error:
                logger.warning(f"ChromeDriverManager failed: {driver_error}")
                logger.info("Trying to use system Chrome driver...")
                service = Service()  # This will try to use chromedriver from PATH

            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")

            self.wait = WebDriverWait(self.driver, SCRAPER_CONFIG['element_wait_timeout'])
            logger.info("Chrome WebDriver initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize WebDriver: {str(e)}")
            logger.error("Please ensure Chrome browser is installed and up to date")
            logger.error("You may also need to manually install ChromeDriver")
            raise

    def _save_to_csv(self, data: Dict):
        """Save a single record to CSV file immediately."""
        try:
            with open(self.csv_filename, 'a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([
                    data.get('listing_id', ''),
                    data.get('title', ''),
                    data.get('price', ''),
                    data.get('description', ''),
                    data.get('image_url', ''),
                    data.get('listing_url', ''),
                ])
            logger.debug(f"Saved data to CSV: {data.get('listing_id', 'Unknown ID')}")
            self._save_to_fyp_csv(data)
        except Exception as e:
            logger.error(f"Failed to save data to CSV: {str(e)}")

    def _save_to_fyp_csv(self, data: Dict):
        """Append a record to CSV/fyp.csv in the same folder as other CSV files."""
        fyp_path = os.path.join(self.csv_folder, "fyp.csv")
        os.makedirs(self.csv_folder, exist_ok=True)

        # If fyp.csv doesn't exist, create it with headers
        if not os.path.exists(fyp_path):
            with open(fyp_path, 'w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(CSV_CONFIG['headers'])
            logger.info(f"Created new fyp.csv at {fyp_path}")

        # Append the data to fyp.csv
        try:
            with open(fyp_path, 'a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([
                    data.get('listing_id', ''),
                    data.get('title', ''),
                    data.get('price', ''),
                    data.get('description', ''),
                    data.get('image_url', ''),
                    data.get('listing_url', ''),
                ])
            logger.debug(f"Appended to fyp.csv: {data.get('listing_id', 'Unknown ID')}")
        except Exception as e:
            logger.error(f"Failed to append to fyp.csv: {str(e)}")
            fyp_path = os.path.join(self.csv_folder, "fyp.csv")
            os.makedirs(self.csv_folder, exist_ok=True)

            # If file doesn't exist, create it with headers
            if not os.path.exists(fyp_path):
                with open(fyp_path, 'w', newline='', encoding='utf-8') as file:
                    writer = csv.writer(file)
                    writer.writerow(CSV_CONFIG['headers'])
                logger.info("Created new fyp.csv file")

            # Append the data
            try:
                with open(fyp_path, 'a', newline='', encoding='utf-8') as file:
                    writer = csv.writer(file)
                    writer.writerow([
                        data.get('listing_id', ''),
                        data.get('title', ''),
                        data.get('price', ''),
                        data.get('description', ''),
                        data.get('image_url', ''),
                        data.get('listing_url', ''),
                    ])
                logger.debug(f"Appended to fyp.csv: {data.get('listing_id', 'Unknown ID')}")
            except Exception as e:
                logger.error(f"Failed to append to fyp.csv: {str(e)}")

    def _extract_listing_id_from_url(self, url: str) -> str:
        """Extract listing ID from Kijiji URL."""
        match = re.search(r'/(\d+)$', url)
        return match.group(1) if match else url

    def _clean_text(self, text: str) -> str:
        """Clean and normalize text."""
        return re.sub(r'\s+', ' ', text.strip()) if text else ''

    def _wait_for_page_load(self, timeout: int = None):
        """Wait for the page to fully load."""
        if timeout is None:
            timeout = SCRAPER_CONFIG['page_load_timeout']

        try:
            # Wait for the profile section to be present (indicates page is loaded)
            wait = WebDriverWait(self.driver, timeout)
            wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR, SELECTORS['page_load_indicator']))
            )
            # Reduced wait time for dynamic content
            time.sleep(1)  # Reduced from 2 to 1 second
            return True
        except TimeoutException:
            logger.warning("Page load timeout - continuing anyway")
            return False

    def _extract_listing_data(self, listing_url: str) -> Dict:
        """Extract data from a single listing page."""
        try:
            logger.info(f"Processing listing: {listing_url}")
            self.driver.get(listing_url)

            if not self._wait_for_page_load():
                logger.warning(f"Page may not have loaded completely: {listing_url}")

            # Extract basic listing information
            data = {
                'listing_id': self._extract_listing_id_from_url(listing_url),
                'listing_url': listing_url,
            }

            # Extract title
            try:
                title_element = self.driver.find_element(By.CSS_SELECTOR, SELECTORS['title'])
                data['title'] = self._clean_text(title_element.text)
            except NoSuchElementException:
                data['title'] = 'N/A'

            # Extract price
            try:
                price_elements = self.driver.find_elements(
                    By.CSS_SELECTOR,
                    SELECTORS['price_elements']
                )
                for element in price_elements:
                    text = element.text.strip()
                    if '$' in text or 'free' in text.lower():
                        data['price'] = self._clean_text(text)
                        break
                else:
                    data['price'] = 'N/A'
            except Exception:
                data['price'] = 'N/A'

            try:
                description_element = self.driver.find_element(By.CSS_SELECTOR, SELECTORS['description_element'])
                data['description'] = self._clean_text(description_element.text)
            except NoSuchElementException:
                data['description'] = 'N/A'

           # Extract image URL
            try:
                # 1. First, try to find the main image
                image_element = WebDriverWait(self.driver, 5).until(  # Use a shorter timeout
                    EC.visibility_of_element_located(
                        (By.CSS_SELECTOR, '[data-testid="gallery-main-image"]')
                    )
                )
                data['image_url'] = image_element.get_attribute("src") + " "
            except NoSuchElementException:
                data['image_url'] = 'N/A'

            return data




        except Exception as e:
            logger.error(f"Error extracting listing data from {listing_url}: {str(e)}")
            return {
                'listing_id': self._extract_listing_id_from_url(listing_url),
                'listing_url': listing_url,
                'title': 'Error',
                'price': 'N/A',
                'description': 'N/A',
                'image_url': 'N/A',
            }

    def _get_listing_links_from_page(self) -> List[str]:
        """Extract all listing links from the current search results page."""
        links = []
        try:
            # Wait for the search results to load
            self.wait.until(
                EC.presence_of_element_located((
                    By.CSS_SELECTOR,
                    SELECTORS['search_results_list']
                ))
            )

            # Find all listing links
            listing_elements = self.driver.find_elements(
                By.CSS_SELECTOR,
                SELECTORS['listing_links']
            )

            for element in listing_elements:
                href = element.get_attribute('href')
                full_url = href if href.startswith('http') else f"https://www.kijiji.ca{href}"
                links.append(full_url)

            logger.info(f"Found {len(links)} listings on current page")
            return links

        except Exception as e:
            logger.error(f"Error getting listing links: {str(e)}")
            return []

    def _has_next_page(self) -> bool:
        """Check if there's a next page available."""
        try:
            # Look for pagination or next page indicators
            next_buttons = self.driver.find_elements(
                By.CSS_SELECTOR,
                'a[aria-label*="Next"], a[title*="Next"], .pagination a:last-child'
            )
            return len(next_buttons) > 0
        except Exception:
            return False

    def _go_to_next_page(self) -> bool:
        """Navigate to the next page of results."""
        try:
            # Try to find and click next page button
            next_button = self.driver.find_element(
                By.CSS_SELECTOR,
                SELECTORS['next_page_button']
            )
            self.driver.execute_script("arguments[0].click();", next_button)
            time.sleep(SCRAPER_CONFIG['page_navigation_delay'])
            return True
        except Exception as e:
            logger.info(f"No next page found or error navigating: {str(e)}")
            return False

    def scrape_listings(self, start_url: str, max_pages: int = None, max_listings: int = None):
        """
        Main method to scrape Kijiji listings.

        Args:
            start_url: The initial Kijiji search URL
            max_pages: Maximum number of pages to scrape (None for all)
            max_listings: Maximum number of listings to process (None for all)
        """
        try:
            self._setup_driver()
            logger.info(f"Starting scrape of Kijiji listings from: {start_url}")

            self.driver.get(start_url)
            time.sleep(SCRAPER_CONFIG['page_navigation_delay'])

            page_count = 0
            total_processed = 0

            while True:
                page_count += 1
                logger.info(f"Processing page {page_count}")

                # Get all listing links from current page
                listing_links = self._get_listing_links_from_page()

                if not listing_links:
                    logger.warning("No listings found on current page")
                    break

                # Process each listing
                for i, listing_url in enumerate(listing_links, 1):
                    if max_listings and total_processed >= max_listings:
                        logger.info(f"Reached maximum listings limit: {max_listings}")
                        return

                    listing_id = self._extract_listing_id_from_url(listing_url)

                    # Skip if already processed
                    if listing_id in self.processed_listings:
                        logger.info(f"Skipping already processed listing: {listing_id}")
                        continue

                    logger.info(f"Processing listing {i}/{len(listing_links)} on page {page_count}")

                    try:
                        # Extract data from listing
                        listing_data = self._extract_listing_data(listing_url)

                        # save to CSV immediately
                        self._save_to_csv(listing_data)

                        # Track processed listings
                        self.processed_listings.add(listing_id)
                        total_processed += 1

                        # Add small delay between requests
                        time.sleep(SCRAPER_CONFIG['between_listings_delay'])

                    except Exception as e:
                        logger.error(f"Error processing listing {listing_url}: {str(e)}")
                        continue

                # Check if we should continue to next page
                if max_pages and page_count >= max_pages:
                    logger.info(f"Reached maximum pages limit: {max_pages}")
                    break

                # Try to go to next page
                if not self._go_to_next_page():
                    logger.info("No more pages available")
                    break

            logger.info(f"Scraping completed. Processed {total_processed} listings across {page_count} pages")

        except KeyboardInterrupt:
            logger.info("Scraping interrupted by user")
        except Exception as e:
            logger.error(f"Error during scraping: {str(e)}")
        finally:
            self._cleanup()

    def _cleanup(self):
        """Clean up resources."""
        if self.driver:
            self.driver.quit()
            logger.info("WebDriver closed")

def main():
    """Main function to run the scraper for a predefined search term."""

    # 1. Define the hardcoded search term
    search_term = "pokemon cards"

    # 2. Format the search term for the URL (best practice, though simple here)
    formatted_search = search_term.lower().replace(' ', '-')

    # 3. Construct the specific start_url
    start_url = f"https://www.kijiji.ca/b-city-of-toronto/{formatted_search}/k0l1700273?dc=true&view=list"

    # Initialize scraper
    scraper = KijijiScraper()  # Uses config settings

    try:
            # Start scraping with the hardcoded URL
            scraper.scrape_listings(
                start_url=start_url,
                max_pages=SCRAPER_CONFIG['max_pages'],
                max_listings=SCRAPER_CONFIG['max_listings']
            )

    except Exception as e:
        logger.error(f"Error in main: {str(e)}")

if __name__ == "__main__":
    main()
