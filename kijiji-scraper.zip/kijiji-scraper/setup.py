#!/usr/bin/env python3
"""
Setup script for Kijiji Scraper
"""

import subprocess
import sys
import os

def install_requirements():
    """Install required packages."""
    try:
        print("Installing required packages...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ All packages installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing packages: {e}")
        return False

def main():
    """Main setup function."""
    print("🚀 Setting up Kijiji Phone Number Scraper")
    print("=" * 50)
    
    # Check if requirements.txt exists
    if not os.path.exists("requirements.txt"):
        print("❌ requirements.txt not found!")
        return
    
    # Install requirements
    if install_requirements():
        print("\n✅ Setup completed successfully!")
        print("\nTo run the scraper:")
        print("python kijiji_scraper.py")
        print("\nThe scraper will:")
        print("- Navigate through Kijiji car listings")
        print("- Extract phone numbers when available") 
        print("- Save results to a timestamped CSV file")
        print("- Update the CSV in real-time as it finds numbers")
    else:
        print("\n❌ Setup failed. Please check the error messages above.")

if __name__ == "__main__":
    main()
