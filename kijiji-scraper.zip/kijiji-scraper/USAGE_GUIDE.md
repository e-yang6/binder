# Kijiji Phone Number Scraper - Usage Guide

## Quick Start

1. **Install Dependencies**:
   ```bash
   python setup.py
   ```

2. **Test the Scraper** (recommended first):
   ```bash
   python test_scraper.py
   ```

3. **Run Full Scraper**:
   ```bash
   python kijiji_scraper.py
   ```

## Configuration

Edit `config.py` to customize the scraper behavior:

### Key Settings

```python
SCRAPER_CONFIG = {
    'headless': False,           # True = no browser window
    'max_pages': 2,             # Number of pages to scrape
    'max_listings': 10,         # Number of listings to process
    'between_listings_delay': 2, # Delay between listings (seconds)
}
```

### For Production Use

To scrape all listings without limits:
```python
SCRAPER_CONFIG = {
    'max_pages': None,      # Process all pages
    'max_listings': None,   # Process all listings
    'headless': True,       # Run without browser window
}
```

## What the Scraper Does

1. **Navigates** to Kijiji Ontario car listings
2. **Finds** all vehicle listings on each page  
3. **Clicks** on each listing individually
4. **Detects** if phone number is available
5. **Reveals** hidden phone numbers by clicking "Reveal"
6. **Extracts** phone number and listing details
7. **Saves** data to CSV file immediately
8. **Continues** to next listing and next page

## Output

Creates a timestamped CSV file like: `kijiji_phone_numbers_20250122_143022.csv`

### CSV Columns:
- `listing_id` - Unique Kijiji listing ID
- `title` - Vehicle title/description  
- `price` - Listed price
- `location` - Seller location
- `phone_number` - Phone number (or 'N/A')
- `listing_url` - Direct link to listing
- `scraped_at` - When data was extracted

### Sample Data:
```csv
listing_id,title,price,location,phone_number,listing_url,scraped_at
1725698304,2021 Subaru Crosstrek Ltd.,$20000,Barry's Bay,+1-613-555-0123,https://www.kijiji.ca/v-cars-trucks/...,2025-01-22T14:30:45
1725698027,Acura tlx 2015,$2500,Mississauga,N/A,https://www.kijiji.ca/v-cars-trucks/...,2025-01-22T14:32:12
```

## Monitoring Progress

The scraper provides detailed logging:

```
2025-01-22 14:30:45 - INFO - Starting scrape of Kijiji listings
2025-01-22 14:30:47 - INFO - Processing page 1
2025-01-22 14:30:48 - INFO - Found 40 listings on current page
2025-01-22 14:30:49 - INFO - Processing listing 1/40 on page 1
2025-01-22 14:30:52 - INFO - Found hidden phone number, clicking to reveal...
2025-01-22 14:30:55 - INFO - Extracted data: 2021 Subaru Crosstrek - Phone: +1-613-555-0123
2025-01-22 14:30:55 - INFO - Saved data to CSV: 1725698304
```

## Error Handling

The scraper handles:
- **Network timeouts** - Retries with delays
- **Missing elements** - Logs and continues
- **Rate limiting** - Built-in delays
- **Duplicate listings** - Skips already processed
- **Page navigation issues** - Logs and stops gracefully

## Performance Tips

### For Speed:
- Set `headless: True` in config
- Reduce delay times (but risk being blocked)
- Limit `max_pages` and `max_listings`

### For Reliability:
- Keep `headless: False` to monitor progress
- Increase delay times if getting blocked
- Run during off-peak hours

## Troubleshooting

### Common Issues:

**"Chrome driver not found"**
- Run `python setup.py` to install dependencies
- Ensure Chrome browser is installed

**"Element not found" errors**
- Kijiji may have changed their page structure
- Check if selectors in `config.py` need updating

**"Access denied" or blocked**
- Increase delays in config
- Try running at different times
- Use different user agent

**No phone numbers found**
- Many listings don't include phone numbers
- Only owner listings (not dealers) typically have phones
- Some sellers only use messaging

### Debug Mode:

1. Set `headless: False` to watch browser
2. Set `max_listings: 1` to test single listing
3. Check browser console for JavaScript errors
4. Verify selectors match current page structure

## Legal Considerations

- ✅ **Respect** Kijiji's terms of service
- ✅ **Use reasonable delays** between requests  
- ✅ **Handle data responsibly** - phone numbers are personal
- ✅ **Don't overwhelm** their servers
- ❌ **Don't use** for commercial spam
- ❌ **Don't scrape** excessively

## Advanced Usage

### Custom URLs:
```python
# Scrape Toronto only
scraper.scrape_listings(URLS['toronto_cars_trucks'])

# Custom search
custom_url = "https://www.kijiji.ca/b-cars-trucks/ottawa/honda/k0c174l1700185"
scraper.scrape_listings(custom_url)
```

### Multiple Regions:
```python
regions = [
    URLS['ontario_cars_trucks'],
    URLS['toronto_cars_trucks'], 
    URLS['vancouver_cars_trucks']
]

for region_url in regions:
    scraper = KijijiScraper()
    scraper.scrape_listings(region_url, max_pages=1)
```

## Support

If you encounter issues:
1. Check the log files for detailed error messages
2. Verify Chrome browser is up to date
3. Test with `python test_scraper.py` first
4. Check if Kijiji has changed their page structure

The scraper is designed to be robust but may need updates if Kijiji changes their website structure.
